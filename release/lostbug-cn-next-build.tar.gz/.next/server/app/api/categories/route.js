var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/categories/route.js")
R.c("server/chunks/[root-of-the-server]__0ukej9j._.js")
R.c("server/chunks/_13tzr4h._.js")
R.c("server/chunks/[root-of-the-server]__1gwwrwu._.js")
R.c("server/chunks/_next-internal_server_app_api_categories_route_actions_195-y1x.js")
R.m(13946)
module.exports=R.m(13946).exports
