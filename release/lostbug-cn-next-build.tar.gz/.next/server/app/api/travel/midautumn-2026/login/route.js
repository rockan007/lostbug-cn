var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/travel/midautumn-2026/login/route.js")
R.c("server/chunks/[root-of-the-server]__1y27xec._.js")
R.c("server/chunks/[root-of-the-server]__1gwwrwu._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_next-internal_server_app_api_travel_midautumn-2026_login_route_actions_208-2v1.js")
R.m(40845)
module.exports=R.m(40845).exports
