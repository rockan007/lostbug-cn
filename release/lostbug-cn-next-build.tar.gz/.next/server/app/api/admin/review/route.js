var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/review/route.js")
R.c("server/chunks/[root-of-the-server]__1ywv792._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_13tzr4h._.js")
R.c("server/chunks/[root-of-the-server]__1gwwrwu._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_review_route_actions_1m4w_hb.js")
R.m(16299)
module.exports=R.m(16299).exports
