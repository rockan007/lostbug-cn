var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/login/route.js")
R.c("server/chunks/[root-of-the-server]__09q5njg._.js")
R.c("server/chunks/[root-of-the-server]__1gwwrwu._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_login_route_actions_14e5p02.js")
R.m(7620)
module.exports=R.m(7620).exports
