var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/search/route.js")
R.c("server/chunks/[root-of-the-server]__035irb4._.js")
R.c("server/chunks/_13tzr4h._.js")
R.c("server/chunks/[root-of-the-server]__1gwwrwu._.js")
R.c("server/chunks/_next-internal_server_app_api_search_route_actions_0k0mocb.js")
R.m(62518)
module.exports=R.m(62518).exports
