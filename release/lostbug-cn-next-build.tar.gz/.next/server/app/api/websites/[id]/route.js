var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/websites/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0h_y2nf._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_13tzr4h._.js")
R.c("server/chunks/[root-of-the-server]__1gwwrwu._.js")
R.c("server/chunks/_next-internal_server_app_api_websites_[id]_route_actions_1bvvkkw.js")
R.m(93226)
module.exports=R.m(93226).exports
