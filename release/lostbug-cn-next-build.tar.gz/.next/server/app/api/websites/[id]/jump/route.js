var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/websites/[id]/jump/route.js")
R.c("server/chunks/[root-of-the-server]__0yvcg59._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/[root-of-the-server]__1gwwrwu._.js")
R.c("server/chunks/_13tzr4h._.js")
R.c("server/chunks/_next-internal_server_app_api_websites_[id]_jump_route_actions_1z5-279.js")
R.m(50196)
module.exports=R.m(50196).exports
