var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/websites/route.js")
R.c("server/chunks/[root-of-the-server]__12hywww._.js")
R.c("server/chunks/_13tzr4h._.js")
R.c("server/chunks/[root-of-the-server]__1gwwrwu._.js")
R.c("server/chunks/_next-internal_server_app_api_websites_route_actions_0nuhtil.js")
R.m(42374)
module.exports=R.m(42374).exports
