globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/TCgCCU2cRFlyombkqDPew/_buildManifest.js",
    "static/TCgCCU2cRFlyombkqDPew/_ssgManifest.js",
    "static/TCgCCU2cRFlyombkqDPew/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0gt4ltgrsn83w.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/11oof8oxnxiv9.js",
    "static/chunks/3peubv2924kx4.js",
    "static/chunks/turbopack-0vgp6p_7of0g6.js"
  ]
};
