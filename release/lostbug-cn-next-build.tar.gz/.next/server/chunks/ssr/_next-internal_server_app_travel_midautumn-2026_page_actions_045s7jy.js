module.exports=[38486,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_travel_midautumn-2026_page_actions_045s7jy.js.map