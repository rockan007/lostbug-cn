module.exports=[67502,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_review_page_actions_0xdq3-g.js.map