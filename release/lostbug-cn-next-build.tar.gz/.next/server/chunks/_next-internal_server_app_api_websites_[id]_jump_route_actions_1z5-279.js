module.exports=[82690,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_websites_%5Bid%5D_jump_route_actions_1z5-279.js.map