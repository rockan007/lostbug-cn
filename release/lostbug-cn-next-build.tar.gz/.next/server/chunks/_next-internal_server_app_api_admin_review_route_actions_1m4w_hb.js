module.exports=[36073,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_review_route_actions_1m4w_hb.js.map