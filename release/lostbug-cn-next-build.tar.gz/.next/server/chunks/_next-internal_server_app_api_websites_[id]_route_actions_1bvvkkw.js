module.exports=[74348,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_websites_%5Bid%5D_route_actions_1bvvkkw.js.map